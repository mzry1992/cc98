package com.example.zjuforum;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

import android.util.Log;

public class LoginNetworkProxy {
	
	public LoginNetworkProxy()
	{
		
	}
	
	public String FetchWebPage()  throws Exception
	{
		String str = null;
		StringBuilder buf = new StringBuilder("http://www.cc98.org/login.asp");
		//StringBuilder buf = new StringBuilder("http://www.baidu.com");
		HttpGet httpRequest = new HttpGet(buf.toString());
		httpRequest.setHeader("Host", "www.cc98.org");
		try 
        { 
          /*����HTTP request*/
          //httpRequest.setEntity(new UrlEncodedFormEntity(params, HTTP.UTF_8)); 
          /*ȡ��HTTP response*/
          HttpResponse httpResponse = new DefaultHttpClient().execute(httpRequest); 
          /*��״̬��Ϊ200 ok*/
          
          if(httpResponse.getStatusLine().getStatusCode()==200){
  			str =  EntityUtils.toString(httpResponse.getEntity()); 
  			Log.e("chaoren",str);
          }
  		}
        catch (ClientProtocolException e) 
        {  
          e.printStackTrace(); 
        } 
        catch (IOException e) 
        {  
          e.printStackTrace(); 
        } 
        catch (Exception e) 
        {  
          e.printStackTrace();  
        }  
		return str;
	}
	
	protected String readString(InputStream in) throws Exception 
	{  
        byte[]data = new byte[1024];  
        int length = 0;  
        ByteArrayOutputStream bout = new ByteArrayOutputStream();  
        while((length=in.read(data))!=-1){  
            bout.write(data,0,length);  
        }  
        return new String(bout.toByteArray(),"UTF-8");  
    }  

}
